﻿namespace GeoQuiz3
{
    partial class Benutzer
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtSpielerName = new TextBox();
            label2 = new Label();
            btnWeiter = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 30F, FontStyle.Bold);
            label1.Location = new Point(144, 52);
            label1.Name = "label1";
            label1.Size = new Size(571, 54);
            label1.TabIndex = 0;
            label1.Text = "Willkommen beim Geo Quiz !";
            // 
            // txtSpielerName
            // 
            txtSpielerName.Location = new Point(341, 212);
            txtSpielerName.Name = "txtSpielerName";
            txtSpielerName.Size = new Size(100, 23);
            txtSpielerName.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            label2.ForeColor = SystemColors.HotTrack;
            label2.Location = new Point(214, 152);
            label2.Name = "label2";
            label2.Size = new Size(367, 37);
            label2.TabIndex = 2;
            label2.Text = "Gib dein Spielernamen ein :";
            // 
            // btnWeiter
            // 
            btnWeiter.Location = new Point(355, 311);
            btnWeiter.Name = "btnWeiter";
            btnWeiter.Size = new Size(75, 23);
            btnWeiter.TabIndex = 3;
            btnWeiter.Text = "Weiter";
            btnWeiter.UseVisualStyleBackColor = true;
            btnWeiter.Click += btnWeiter_Click;
            // 
            // Benutzer
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnWeiter);
            Controls.Add(label2);
            Controls.Add(txtSpielerName);
            Controls.Add(label1);
            Name = "Benutzer";
            Text = "Benutzer";
            Load += Benutzer_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtSpielerName;
        private Label label2;
        private Button btnWeiter;
    }
}
