﻿namespace GeoQuiz3
{
    partial class QuizForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBoxFlagge = new PictureBox();
            btnAntwort1 = new Button();
            btnAntwort2 = new Button();
            btnAntwort3 = new Button();
            btnAntwort4 = new Button();
            labelFrageNummer = new Label();
            labelRueckmeldung = new Label();
            labelFrageText = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxFlagge).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // pictureBoxFlagge
            // 
            pictureBoxFlagge.Location = new Point(213, 12);
            pictureBoxFlagge.Name = "pictureBoxFlagge";
            pictureBoxFlagge.Size = new Size(309, 248);
            pictureBoxFlagge.TabIndex = 0;
            pictureBoxFlagge.TabStop = false;
            // 
            // btnAntwort1
            // 
            btnAntwort1.Location = new Point(112, 281);
            btnAntwort1.Name = "btnAntwort1";
            btnAntwort1.Size = new Size(103, 41);
            btnAntwort1.TabIndex = 1;
            btnAntwort1.Text = "button1";
            btnAntwort1.UseVisualStyleBackColor = true;
            // 
            // btnAntwort2
            // 
            btnAntwort2.Location = new Point(510, 275);
            btnAntwort2.Name = "btnAntwort2";
            btnAntwort2.Size = new Size(101, 47);
            btnAntwort2.TabIndex = 2;
            btnAntwort2.Text = "button2";
            btnAntwort2.UseVisualStyleBackColor = true;
            // 
            // btnAntwort3
            // 
            btnAntwort3.Location = new Point(112, 365);
            btnAntwort3.Name = "btnAntwort3";
            btnAntwort3.Size = new Size(103, 45);
            btnAntwort3.TabIndex = 3;
            btnAntwort3.Text = "button3";
            btnAntwort3.UseVisualStyleBackColor = true;
            // 
            // btnAntwort4
            // 
            btnAntwort4.Location = new Point(510, 365);
            btnAntwort4.Name = "btnAntwort4";
            btnAntwort4.Size = new Size(101, 45);
            btnAntwort4.TabIndex = 4;
            btnAntwort4.Text = "button4";
            btnAntwort4.UseVisualStyleBackColor = true;
            // 
            // labelFrageNummer
            // 
            labelFrageNummer.AutoSize = true;
            labelFrageNummer.Location = new Point(596, 54);
            labelFrageNummer.Name = "labelFrageNummer";
            labelFrageNummer.Size = new Size(38, 15);
            labelFrageNummer.TabIndex = 5;
            labelFrageNummer.Text = "label1";
            // 
            // labelRueckmeldung
            // 
            labelRueckmeldung.AutoSize = true;
            labelRueckmeldung.Location = new Point(335, 329);
            labelRueckmeldung.Name = "labelRueckmeldung";
            labelRueckmeldung.Size = new Size(38, 15);
            labelRueckmeldung.TabIndex = 6;
            labelRueckmeldung.Text = "label2";
            // 
            // labelFrageText
            // 
            labelFrageText.AutoSize = true;
            labelFrageText.Location = new Point(335, 160);
            labelFrageText.Name = "labelFrageText";
            labelFrageText.Size = new Size(38, 15);
            labelFrageText.TabIndex = 7;
            labelFrageText.Text = "label1";
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(112, 275);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(103, 47);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
           // pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(112, 360);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(103, 50);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 9;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Location = new Point(511, 272);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(100, 50);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
           // pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Location = new Point(510, 360);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(100, 50);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 11;
            pictureBox4.TabStop = false;
            // 
            // QuizForms
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(labelFrageText);
            Controls.Add(labelRueckmeldung);
            Controls.Add(labelFrageNummer);
            Controls.Add(btnAntwort4);
            Controls.Add(btnAntwort3);
            Controls.Add(btnAntwort2);
            Controls.Add(btnAntwort1);
            Controls.Add(pictureBoxFlagge);
            Name = "QuizForms";
            Text = "QuizForms";
            Load += QuizForms_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxFlagge).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBoxFlagge;
        private Button btnAntwort1;
        private Button btnAntwort2;
        private Button btnAntwort3;
        private Button btnAntwort4;
        private Label labelFrageNummer;
        private Label labelRueckmeldung;
        private Label labelFrageText;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
    }
}