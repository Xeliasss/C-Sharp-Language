﻿namespace GeoQuiz3
{
    partial class Quiz_WahlForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            groupBox1 = new GroupBox();
            rbFlaggeErraten = new RadioButton();
            rbHauptstadtErraten = new RadioButton();
            rbLandErraten = new RadioButton();
            groupBox2 = new GroupBox();
            rbFlaggeAnzeigen = new RadioButton();
            rbHauptstadtAnzeigen = new RadioButton();
            rbLandAnzeigen = new RadioButton();
            btnStart = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            label1.Location = new Point(218, 37);
            label1.Name = "label1";
            label1.Size = new Size(352, 46);
            label1.TabIndex = 0;
            label1.Text = "Wähle dein Quiz aus ";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rbFlaggeErraten);
            groupBox1.Controls.Add(rbHauptstadtErraten);
            groupBox1.Controls.Add(rbLandErraten);
            groupBox1.Location = new Point(80, 136);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(252, 192);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = " Was soll erraten werden? ";
            // 
            // rbFlaggeErraten
            // 
            rbFlaggeErraten.AutoSize = true;
            rbFlaggeErraten.Location = new Point(47, 135);
            rbFlaggeErraten.Name = "rbFlaggeErraten";
            rbFlaggeErraten.Size = new Size(60, 19);
            rbFlaggeErraten.TabIndex = 2;
            rbFlaggeErraten.TabStop = true;
            rbFlaggeErraten.Text = "Flagge";
            rbFlaggeErraten.UseVisualStyleBackColor = true;
            // 
            // rbHauptstadtErraten
            // 
            rbHauptstadtErraten.AutoSize = true;
            rbHauptstadtErraten.Location = new Point(47, 90);
            rbHauptstadtErraten.Name = "rbHauptstadtErraten";
            rbHauptstadtErraten.Size = new Size(84, 19);
            rbHauptstadtErraten.TabIndex = 1;
            rbHauptstadtErraten.TabStop = true;
            rbHauptstadtErraten.Text = "Hauptstadt";
            rbHauptstadtErraten.UseVisualStyleBackColor = true;
            // 
            // rbLandErraten
            // 
            rbLandErraten.AutoSize = true;
            rbLandErraten.Location = new Point(47, 53);
            rbLandErraten.Name = "rbLandErraten";
            rbLandErraten.Size = new Size(51, 19);
            rbLandErraten.TabIndex = 0;
            rbLandErraten.TabStop = true;
            rbLandErraten.Text = "Land";
            rbLandErraten.UseVisualStyleBackColor = true;
            rbLandErraten.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(rbFlaggeAnzeigen);
            groupBox2.Controls.Add(rbHauptstadtAnzeigen);
            groupBox2.Controls.Add(rbLandAnzeigen);
            groupBox2.Location = new Point(464, 143);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(225, 185);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "  Was soll angezeigt werden? ";
            // 
            // rbFlaggeAnzeigen
            // 
            rbFlaggeAnzeigen.AutoSize = true;
            rbFlaggeAnzeigen.Location = new Point(57, 128);
            rbFlaggeAnzeigen.Name = "rbFlaggeAnzeigen";
            rbFlaggeAnzeigen.Size = new Size(60, 19);
            rbFlaggeAnzeigen.TabIndex = 2;
            rbFlaggeAnzeigen.TabStop = true;
            rbFlaggeAnzeigen.Text = "Flagge";
            rbFlaggeAnzeigen.UseVisualStyleBackColor = true;
            // 
            // rbHauptstadtAnzeigen
            // 
            rbHauptstadtAnzeigen.AutoSize = true;
            rbHauptstadtAnzeigen.Location = new Point(57, 83);
            rbHauptstadtAnzeigen.Name = "rbHauptstadtAnzeigen";
            rbHauptstadtAnzeigen.Size = new Size(84, 19);
            rbHauptstadtAnzeigen.TabIndex = 1;
            rbHauptstadtAnzeigen.TabStop = true;
            rbHauptstadtAnzeigen.Text = "Hauptstadt";
            rbHauptstadtAnzeigen.UseVisualStyleBackColor = true;
            // 
            // rbLandAnzeigen
            // 
            rbLandAnzeigen.AutoSize = true;
            rbLandAnzeigen.Location = new Point(57, 46);
            rbLandAnzeigen.Name = "rbLandAnzeigen";
            rbLandAnzeigen.Size = new Size(51, 19);
            rbLandAnzeigen.TabIndex = 0;
            rbLandAnzeigen.TabStop = true;
            rbLandAnzeigen.Text = "Land";
            rbLandAnzeigen.UseVisualStyleBackColor = true;
            // 
            // btnStart
            // 
            btnStart.Location = new Point(360, 380);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(75, 23);
            btnStart.TabIndex = 3;
            btnStart.Text = "Start";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click_1;
            // 
            // Quiz_WahlForms
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnStart);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Name = "Quiz_WahlForms";
            Text = "Quiz_WahlForms";
            Load += Quiz_WahlForms_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private RadioButton rbFlaggeErraten;
        private RadioButton rbHauptstadtErraten;
        private RadioButton rbLandErraten;
        private GroupBox groupBox2;
        private RadioButton rbHauptstadtAnzeigen;
        private RadioButton rbLandAnzeigen;
        private RadioButton rbFlaggeAnzeigen;
        private Button btnStart;
    }
}