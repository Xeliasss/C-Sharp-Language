﻿using System;
using System.Windows.Forms;

namespace GeoQuiz3
{
    // Dieses Formular ermöglicht es dem Spieler, den gewünschten Quizmodus auszuwählen
    public partial class Quiz_WahlForms : Form
    {
        private string spielerName; // Zwischenspeicherung des Spielernamens

        // Öffentliche Eigenschaften zur Speicherung der Auswahl
        public string Erraten { get; private set; }  // Was soll erraten werden?
        public string Anzeigen { get; private set; } // Was wird angezeigt?

        // Konstruktor: Initialisierung des Formulars
        public Quiz_WahlForms()
        {
            InitializeComponent(); // UI-Elemente laden
            this.spielerName = Benutzer.benutzername; // Spielername aus vorherigem Formular übernehmen

            // Eventhandler für Änderung der Auswahl "Was soll erraten werden?"
            rbLandErraten.CheckedChanged += Erraten_CheckedChanged;
            rbHauptstadtErraten.CheckedChanged += Erraten_CheckedChanged;
            rbFlaggeErraten.CheckedChanged += Erraten_CheckedChanged;

            // Begrüßung im Fenstertitel
            this.Text = $"Willkommen, {spielerName}!";
        }

        // Wird beim Laden des Formulars aufgerufen
        private void Quiz_WahlForms_Load(object sender, EventArgs e)
        {
            // Standardauswahl setzen
            rbLandErraten.Checked = true;
            rbHauptstadtAnzeigen.Checked = true;
            UpdateAnzeigenOptions(); // Anzeigeoptionen anpassen
        }

        // Wird aufgerufen, wenn sich die Auswahl ändert, was erraten werden soll
        private void Erraten_CheckedChanged(object sender, EventArgs e)
        {
            UpdateAnzeigenOptions(); // Anzeigeoptionen dynamisch anpassen
        }

        // Diese Methode deaktiviert die Anzeigeoption, die gerade zum Erraten ausgewählt wurde
        private void UpdateAnzeigenOptions()
        {
            // Alle drei Anzeigeoptionen aktivieren
            rbLandAnzeigen.Enabled = true;
            rbHauptstadtAnzeigen.Enabled = true;
            rbFlaggeAnzeigen.Enabled = true;

            // Je nachdem, was erraten werden soll, die gleiche Anzeigeoption deaktivieren
            if (rbLandErraten.Checked)
            {
                rbLandAnzeigen.Enabled = false;
                if (rbLandAnzeigen.Checked) rbLandAnzeigen.Checked = false;
            }
            else if (rbHauptstadtErraten.Checked)
            {
                rbHauptstadtAnzeigen.Enabled = false;
                if (rbHauptstadtAnzeigen.Checked) rbHauptstadtAnzeigen.Checked = false;
            }
            else if (rbFlaggeErraten.Checked)
            {
                rbFlaggeAnzeigen.Enabled = false;
                if (rbFlaggeAnzeigen.Checked) rbFlaggeAnzeigen.Checked = false;
            }
        }

        // Debugging-Funktion: zeigt an, wenn Radiobutton geändert wurde (derzeit ungenutzt)
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Console.WriteLine("Land-RadioButton wurde geändert.");
        }

        // Wird aufgerufen, wenn der Spieler auf "Start" klickt
        private void btnStart_Click_1(object sender, EventArgs e)
        {
            // Validierung: Wurde eine Erraten- und eine Anzeigen-Option gewählt?
            if (!rbLandErraten.Checked && !rbHauptstadtErraten.Checked && !rbFlaggeErraten.Checked)
            {
                MessageBox.Show("Bitte wählen Sie, was erraten werden soll.");
                return;
            }
            if (!rbLandAnzeigen.Checked && !rbHauptstadtAnzeigen.Checked && !rbFlaggeAnzeigen.Checked)
            {
                MessageBox.Show("Bitte wählen Sie, was angezeigt werden soll.");
                return;
            }

            // Auswahl speichern in den Eigenschaften Erraten und Anzeigen
            if (rbLandErraten.Checked) Erraten = "land";
            else if (rbHauptstadtErraten.Checked) Erraten = "hauptstadt";
            else if (rbFlaggeErraten.Checked) Erraten = "flagge";

            if (rbLandAnzeigen.Checked) Anzeigen = "land";
            else if (rbHauptstadtAnzeigen.Checked) Anzeigen = "hauptstadt";
            else if (rbFlaggeAnzeigen.Checked) Anzeigen = "flagge";

            // Modus als String zusammenbauen (z. B. "hauptstadt_zu_land")
            string modus = $"{Anzeigen}_zu_{Erraten}";

            this.Hide(); // Dieses Formular verstecken

            // Neues Quiz-Formular mit dem gewählten Modus starten
            using (QuizForms quizForm = new QuizForms(modus))
            {
                quizForm.ShowDialog(); // Warten, bis das Quiz abgeschlossen ist
            }
        }
    }
}
