﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace GeoQuiz3
{
    public partial class QuizForms : Form
    {
        // Index der aktuellen Frage
        private int aktuelleFrageIndex = 0;

        // Der gewählte Modus, z.B. "land_zu_flagge"
        private string modus;

        // Liste aller Fragen, die für dieses Quiz geladen wurden
        private List<Frage> fragenListe;

        // Die Antwortbuttons (bei Textantworten)
        private List<Button> antwortButtons;

        // Die Antwort-Bildboxen (bei Flaggen als Antwort)
        private List<PictureBox> antwortPictureBoxes;

        // Die richtige Antwort zur aktuellen Frage
        private string richtigeAntwort;

        // Wie viele Fragen im Quiz gestellt werden
        private int gesamtFragen = 10;

        // Der Name des Spielers (aus Benutzerklasse geladen)
        private string spielerName;

        // Timer, der automatisch zur nächsten Frage übergeht
        private System.Windows.Forms.Timer naechsteFrageTimer;

        // Der Punktestand des Spielers
        private int punktestand = 0;

        // Konstruktor – wird aufgerufen, wenn das Quiz gestartet wird
        public QuizForms(string modus)
        {
            InitializeComponent();
            this.modus = modus;
            this.spielerName = Benutzer.benutzername; // Spielername vom Login
        }

        // Wird beim Laden des Formulars (Fensters) ausgeführt
        private void QuizForms_Load(object sender, EventArgs e)
        {
            InitializeAntwortControls(); // Antwortfelder vorbereiten

            // Fragen aus der Datenbank laden (nach Modus gefiltert)
            Datenbank db = new Datenbank();
            fragenListe = string.IsNullOrEmpty(modus)
                ? db.LadeFragenAusDatenbank()
                : db.LadeFragenAusDatenbank(modus);

            if (fragenListe == null || fragenListe.Count == 0)
            {
                MessageBox.Show("Keine Fragen gefunden!");
                Close();
                return;
            }

            // Fragen zufällig mischen und auf 10 begrenzen
            fragenListe = fragenListe.OrderBy(x => Guid.NewGuid()).Take(gesamtFragen).ToList();
            punktestand = 0;
            ZeigeNaechsteFrage();
        }

        // Initialisiert Buttons und Bildboxen für Antworten
        private void InitializeAntwortControls()
        {
            antwortButtons = new List<Button> { btnAntwort1, btnAntwort2, btnAntwort3, btnAntwort4 };
            antwortPictureBoxes = new List<PictureBox> { pictureBox1, pictureBox2, pictureBox3, pictureBox4 };

            // Buttons mit Klick-Ereignis verknüpfen
            foreach (var btn in antwortButtons)
                btn.Click += AntwortButton_Click;

            // Bildboxen klickbar machen
            foreach (var picBox in antwortPictureBoxes)
            {
                picBox.Cursor = Cursors.Hand;
                picBox.Click += AntwortPictureBox_Click;
            }
        }

        // Zeigt die große Flagge (bei Flagge als Frage)
        private void ZeigeFlagge(string flaggeDatei)
        {
            string bildPfad = HoleFlaggenPfad(flaggeDatei);
            pictureBoxFlagge.Image?.Dispose();

            if (File.Exists(bildPfad))
                pictureBoxFlagge.Image = Image.FromFile(bildPfad);
            else
            {
                pictureBoxFlagge.Image = null;
                MessageBox.Show("Flaggenbild nicht gefunden: " + bildPfad);
            }
        }

        // Gibt den vollständigen Pfad zu einer Flagge zurück
        private string HoleFlaggenPfad(string dateiname)
        {
            string projektPfad = AppDomain.CurrentDomain.BaseDirectory;
            string basisOrdner = Path.GetFullPath(Path.Combine(projektPfad, @"..\..\.."));
            string flaggenOrdner = Path.Combine(basisOrdner, "flags", "png");
            return Path.Combine(flaggenOrdner, dateiname.ToUpper());
        }

        // Zeigt eine Antwort-Flagge an einer bestimmten Stelle
        private void ZeigeAntwortFlagge(int index, string flaggeDatei)
        {
            if (index < 0 || index >= antwortPictureBoxes.Count) return;

            string bildPfad = HoleFlaggenPfad(flaggeDatei);
            PictureBox picBox = antwortPictureBoxes[index];
            picBox.Image?.Dispose();

            if (File.Exists(bildPfad))
            {
                picBox.Image = Image.FromFile(bildPfad);
                picBox.Visible = true;
                picBox.Tag = flaggeDatei; // Wird später zum Vergleichen gebraucht
                picBox.Enabled = true;
            }
            else
            {
                picBox.Image = null;
                picBox.Visible = false;
                picBox.Tag = null;
                picBox.Enabled = false;
            }
        }

        // Blendet alle Antwort-Flaggen aus
        private void VerbergeAntwortFlaggen()
        {
            foreach (var picBox in antwortPictureBoxes)
            {
                picBox.Image?.Dispose();
                picBox.Image = null;
                picBox.Visible = false;
                picBox.Tag = null;
                picBox.Enabled = false;
            }
        }

        // Zeigt die nächste Frage im Quiz
        private void ZeigeNaechsteFrage()
        {
            if (aktuelleFrageIndex >= fragenListe.Count)
            {
                QuizBeenden();
                return;
            }

            labelFrageNummer.Text = $"Frage {aktuelleFrageIndex + 1} von {gesamtFragen} | Punkte: {punktestand}";
            labelRueckmeldung.Text = "";

            Frage frage = fragenListe[aktuelleFrageIndex];
            List<string> antworten = new();
            bool antwortenSindFlaggen = modus.EndsWith("_zu_flagge");

            pictureBoxFlagge.Visible = false;
            labelFrageText.Visible = false;
            VerbergeAntwortFlaggen();

            // Je nach Modus die passende Frage + Antworten anzeigen
            switch (modus)
            {
                case "land_zu_flagge":
                    labelFrageText.Text = frage.Land;
                    richtigeAntwort = frage.FlaggenDatei;
                    antworten.Add(frage.FlaggenDatei);
                    antworten.AddRange(fragenListe.Where(f => f.FlaggenDatei != frage.FlaggenDatei).OrderBy(_ => Guid.NewGuid()).Take(3).Select(f => f.FlaggenDatei));
                    labelFrageText.Visible = true;
                    break;

                case "land_zu_hauptstadt":
                    labelFrageText.Text = frage.Land;
                    richtigeAntwort = frage.Hauptstadt;
                    antworten.Add(frage.Hauptstadt);
                    antworten.AddRange(fragenListe.Where(f => f.Hauptstadt != frage.Hauptstadt).OrderBy(_ => Guid.NewGuid()).Take(3).Select(f => f.Hauptstadt));
                    labelFrageText.Visible = true;
                    break;

                case "hauptstadt_zu_land":
                    labelFrageText.Text = frage.Hauptstadt;
                    richtigeAntwort = frage.Land;
                    antworten.Add(frage.Land);
                    antworten.AddRange(fragenListe.Where(f => f.Land != frage.Land).OrderBy(_ => Guid.NewGuid()).Take(3).Select(f => f.Land));
                    labelFrageText.Visible = true;
                    break;

                case "hauptstadt_zu_flagge":
                    labelFrageText.Text = frage.Hauptstadt;
                    richtigeAntwort = frage.FlaggenDatei;
                    antworten.Add(frage.FlaggenDatei);
                    antworten.AddRange(fragenListe.Where(f => f.FlaggenDatei != frage.FlaggenDatei).OrderBy(_ => Guid.NewGuid()).Take(3).Select(f => f.FlaggenDatei));
                    labelFrageText.Visible = true;
                    break;

                case "flagge_zu_land":
                    richtigeAntwort = frage.Land;
                    ZeigeFlagge(frage.FlaggenDatei);
                    antworten.Add(frage.Land);
                    antworten.AddRange(fragenListe.Where(f => f.Land != frage.Land).OrderBy(_ => Guid.NewGuid()).Take(3).Select(f => f.Land));
                    pictureBoxFlagge.Visible = true;
                    break;

                case "flagge_zu_hauptstadt":
                    richtigeAntwort = frage.Hauptstadt;
                    ZeigeFlagge(frage.FlaggenDatei);
                    antworten.Add(frage.Hauptstadt);
                    antworten.AddRange(fragenListe.Where(f => f.Hauptstadt != frage.Hauptstadt).OrderBy(_ => Guid.NewGuid()).Take(3).Select(f => f.Hauptstadt));
                    pictureBoxFlagge.Visible = true;
                    break;

                default:
                    MessageBox.Show("Unbekannter Modus: " + modus);
                    return;
            }

            // Antworten mischen
            antworten = antworten.OrderBy(_ => Guid.NewGuid()).ToList();

            // Buttons oder Bilder setzen
            for (int i = 0; i < antwortButtons.Count; i++)
            {
                antwortButtons[i].Visible = !antwortenSindFlaggen;
                antwortButtons[i].Enabled = true;
                antwortButtons[i].Text = antwortenSindFlaggen ? "" : antworten[i];
            }

            // Falls Flaggen verwendet werden, zeige sie
            if (antwortenSindFlaggen)
            {
                for (int i = 0; i < antwortPictureBoxes.Count; i++)
                {
                    ZeigeAntwortFlagge(i, antworten[i]);
                }
            }
        }

        // Wird ausgelöst, wenn ein Antwort-Button geklickt wird
        private void AntwortButton_Click(object sender, EventArgs e)
        {
            if (sender is Button gedrueckterButton)
                PruefeAntwort(gedrueckterButton.Text);
        }

        // Wird ausgelöst, wenn auf eine Flagge geklickt wird
        private void AntwortPictureBox_Click(object sender, EventArgs e)
        {
            if (sender is PictureBox gedruecktePictureBox)
            {
                string userAntwort = gedruecktePictureBox.Tag as string;
                if (!string.IsNullOrEmpty(userAntwort))
                    PruefeAntwort(userAntwort);
            }
        }

        // Prüft, ob die Antwort korrekt war
        private void PruefeAntwort(string userAntwort)
        {
            if (string.IsNullOrEmpty(userAntwort)) return;

            bool richtig = userAntwort.Equals(richtigeAntwort, StringComparison.OrdinalIgnoreCase);
            if (richtig) punktestand++;  // Punktestand erhöhen

            labelRueckmeldung.Text = richtig ? "Richtig!" : $"Falsch! Richtige Antwort: {richtigeAntwort}";
            labelRueckmeldung.ForeColor = richtig ? Color.Green : Color.Red;

            antwortButtons.ForEach(btn => btn.Enabled = false);
            antwortPictureBoxes.ForEach(pic => pic.Enabled = false);

            // Timer starten, damit automatisch nächste Frage erscheint
            naechsteFrageTimer?.Stop();
            naechsteFrageTimer?.Dispose();

            naechsteFrageTimer = new System.Windows.Forms.Timer { Interval = 1000 };
            naechsteFrageTimer.Tick += (s, e) =>
            {
                naechsteFrageTimer.Stop();
                naechsteFrageTimer.Dispose();
                naechsteFrageTimer = null;

                aktuelleFrageIndex++;
                ZeigeNaechsteFrage();
            };
            naechsteFrageTimer.Start();
        }

        // Wird aufgerufen, wenn alle Fragen durch sind
        private void QuizBeenden()
        {
            this.Hide(); // Quiz-Fenster ausblenden

            // Highscore-Fenster öffnen
            Highscore highscoreForm = new Highscore(punktestand, gesamtFragen);
            highscoreForm.Show();

            // Punktestand in die Datenbank speichern
            Datenbank db = new Datenbank();
            int punkte = 10;
            db.SpeichereHighscore(spielerName, punkte);
        }
    }
}

