﻿namespace GeoQuiz3
{
    partial class Highscore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnZurueck = new Button();
            dataGridViewHc = new DataGridView();
            Platz = new DataGridViewTextBoxColumn();
            Name = new DataGridViewTextBoxColumn();
            Punkte = new DataGridViewTextBoxColumn();
            Datum = new DataGridViewTextBoxColumn();
            labelErgebnis = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridViewHc).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Viner Hand ITC", 30F, FontStyle.Bold);
            label1.Location = new Point(288, 40);
            label1.Name = "label1";
            label1.Size = new Size(209, 65);
            label1.TabIndex = 0;
            label1.Text = "Highscore";
            // 
            // btnZurueck
            // 
            btnZurueck.Location = new Point(341, 406);
            btnZurueck.Name = "btnZurueck";
            btnZurueck.Size = new Size(75, 23);
            btnZurueck.TabIndex = 1;
            btnZurueck.Text = "Zurück";
            btnZurueck.UseVisualStyleBackColor = true;
            // 
            // dataGridViewHc
            // 
            dataGridViewHc.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewHc.Columns.AddRange(new DataGridViewColumn[] { Platz, Name, Punkte, Datum });
            dataGridViewHc.Location = new Point(179, 185);
            dataGridViewHc.Name = "dataGridViewHc";
            dataGridViewHc.Size = new Size(442, 215);
            dataGridViewHc.TabIndex = 2;
            // 
            // Platz
            // 
            Platz.HeaderText = "Platz";
            Platz.Name = "Platz";
            // 
            // Name
            // 
            Name.HeaderText = "Name";
            Name.Name = "Name";
            // 
            // Punkte
            // 
            Punkte.HeaderText = "Punkte";
            Punkte.Name = "Punkte";
            // 
            // Datum
            // 
            Datum.HeaderText = "Datum";
            Datum.Name = "Datum";
            // 
            // labelErgebnis
            // 
            labelErgebnis.AutoSize = true;
            labelErgebnis.Location = new Point(362, 132);
            labelErgebnis.Name = "labelErgebnis";
            labelErgebnis.Size = new Size(38, 15);
            labelErgebnis.TabIndex = 3;
            labelErgebnis.Text = "label2";
            // 
            // Highscore
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(labelErgebnis);
            Controls.Add(dataGridViewHc);
            Controls.Add(btnZurueck);
            Controls.Add(label1);
//            Name = "Highscore";
            Load += Highscore_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewHc).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnZurueck;
        private DataGridView dataGridViewHc;
        private DataGridViewTextBoxColumn Platz;
        private DataGridViewTextBoxColumn Name;
        private DataGridViewTextBoxColumn Punkte;
        private DataGridViewTextBoxColumn Datum;
        private Label labelErgebnis;
    }
}