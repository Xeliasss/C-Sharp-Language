﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

namespace GeoQuiz3
{
    public class Datenbank
    {
        string connStr = "server=localhost;user=root;database=geo_quiz;";

        public List<Frage> LadeFragenAusDatenbank(string? modus = null)
        {
            var liste = new List<Frage>();

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                conn.Open();

                string sql;

                if (modus == "flagge_zu_land")
                {
                    sql = "SELECT land, hauptstadt, flagge_datei FROM laender LIMIT 15";
                }
                else if (modus == "hauptstadt_zu_land")
                {
                    sql = "SELECT land, hauptstadt, flagge_datei FROM laender LIMIT 15";
                }
                else if (modus == "land_zu_hauptstadt")
                {
                    sql = "SELECT land, hauptstadt, flagge_datei FROM laender LIMIT 15";
                }
                else
                {
                    sql = "SELECT land, hauptstadt, flagge_datei FROM laender LIMIT 15";
                }

                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        liste.Add(new Frage
                        {
                            Land = reader.GetString("land"),
                            Hauptstadt = reader.GetString("hauptstadt"),
                            FlaggenDatei = reader.GetString("flagge_datei")
                        });
                    }
                }
            }

            return liste;
        }

        public void SpeichereHighscore(string spielerName, int punkte)
        {
            string connectionString = "server=localhost;user=root;database=geo_quiz;";

            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                try
                {
                    string query = "INSERT INTO highscores (spieler, punkte, datum) VALUES (@spieler, @punkte, NOW())";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@spieler", spielerName);
                        command.Parameters.AddWithValue("@punkte", punkte);

                        command.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Fehler beim Speichern des Highscores: " + e.Message);
                }
            }
        }



        public List<HighscoreEintrag> LadeHighscores()
        {
            var liste = new List<HighscoreEintrag>();
            string connectionString = "server=localhost;user=root;database=geo_quiz;";


            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                try { 
                string query = @"
            SELECT h.spieler, h.punkte, h.datum
            FROM highscores h 
            group by spieler
            ORDER BY h.punkte DESC
            LIMIT 10;";

                using (var command = new MySqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var eintrag = new HighscoreEintrag
                        {
                            Name = reader.GetString("spieler"),
                            Punkte = reader.GetInt32("punkte"),
                            Datum = reader.GetDateTime("datum")
                        };
                        liste.Add(eintrag);
                    }
                }
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
            }


            return liste;
        }


    }
}
