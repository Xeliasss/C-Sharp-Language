using System;
using System.Windows.Forms;

namespace GeoQuiz3
{
    // Formular zur Eingabe des Spielernamens vor Quiz-Beginn
    public partial class Benutzer : Form
    {
        // �ffentlicher, statischer Benutzername, damit er global verf�gbar ist
        public static string benutzername;

        // Konstruktor: Initialisiert das Formular
        public Benutzer()
        {
            InitializeComponent(); // L�dt die UI-Elemente des Formulars
        }

        // Wird ausgel�st, wenn auf den Button "Weiter" geklickt wird
        private void btnWeiter_Click(object sender, EventArgs e)
        {
            // Spielername wird aus der Textbox gelesen und Leerzeichen werden entfernt
            string spielerName = txtSpielerName.Text.Trim();
            benutzername = spielerName;

            // Pr�fen, ob der Spielername leer ist
            if (string.IsNullOrEmpty(spielerName))
            {
                // Wenn kein Name eingegeben wurde, zeige eine Fehlermeldung
                MessageBox.Show("Bitte gib einen Spielernamen ein.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Abbruch der Methode
            }

            // Erstellen des n�chsten Formulars (Quiz-Modus-Wahl) und Anzeigen
            Quiz_WahlForms quizForm = new Quiz_WahlForms();
            quizForm.Show();

            // Das aktuelle Fenster ausblenden
            this.Hide();
        }

        // Wird ausgel�st, wenn das Formular geladen wird (derzeit ungenutzt)
        private void Benutzer_Load(object sender, EventArgs e)
        {
            // Optional: Initialisierung beim Laden des Formulars
        }
    }
}
