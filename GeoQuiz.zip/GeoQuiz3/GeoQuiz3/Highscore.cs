﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace GeoQuiz3
{
    public partial class Highscore : Form
    {
        // Felder zur Speicherung der erreichten Punktzahl und der Gesamtanzahl der Fragen
        private int punkte;
        private int gesamt;

        /// <summary>
        /// Konstruktor, der mit den übergebenen Punktzahlen initialisiert wird.
        /// Wird verwendet, wenn das Ergebnis nach einem Quiz angezeigt werden soll.
        /// </summary>
        /// <param name="punkte">Anzahl der richtig beantworteten Fragen</param>
        /// <param name="gesamt">Gesamtanzahl der Fragen</param>
        public Highscore(int punkte, int gesamt)
        {
            InitializeComponent(); // Initialisiert die grafischen Komponenten
            this.punkte = punkte;
            this.gesamt = gesamt;
        }

        /// <summary>
        /// Parameterloser Konstruktor, z. B. wenn das Fenster nur zur Ansicht geöffnet wird.
        /// </summary>
        public Highscore()
        {
            InitializeComponent(); // Initialisiert die grafischen Komponenten
        }

        /// <summary>
        /// Wird beim Laden des Highscore-Fensters automatisch ausgeführt.
        /// Zeigt das Spielergebnis an und lädt die Highscore-Tabelle aus der Datenbank.
        /// </summary>
        private void Highscore_Load(object sender, EventArgs e)
        {
            // Zeige das aktuelle Ergebnis (z. B. "Dein Ergebnis: 7 von 10 Punkten")
            labelErgebnis.Text = $"Dein Ergebnis: {punkte} von {gesamt} Punkten";

            // Erzeuge eine neue Instanz der (simulierten oder echten) Datenbank
            Datenbank db = new Datenbank();

            // Lade alle bisherigen Highscore-Einträge
            List<HighscoreEintrag> highscores = db.LadeHighscores();

            // Lösche vorherige Einträge und Spalten im DataGridView (zur Sicherheit)
            dataGridViewHc.Rows.Clear();
            dataGridViewHc.Columns.Clear();

            // Definiere die Spalten für die Anzeige im DataGridView
            dataGridViewHc.Columns.Add("Platz", "Platz");
            dataGridViewHc.Columns.Add("Name", "Name");
            dataGridViewHc.Columns.Add("Punkte", "Punkte");
            dataGridViewHc.Columns.Add("Datum", "Datum");

            // Zähler für die Platzierung (1. Platz, 2. Platz, …)
            int platz = 1;

            // Füge jede Highscore-Zeile zur Tabelle hinzu
            foreach (var eintrag in highscores)
            {
                dataGridViewHc.Rows.Add(
                    platz,                              // Platzierung
                    eintrag.Name,                       // Spielername
                    eintrag.Punkte,                     // Erreichte Punktzahl
                    eintrag.Datum.ToShortDateString()   // Datum im Kurzformat (z. B. 27.06.2025)
                );
                platz++; // Nächster Platz
            }
        }
    }
}
