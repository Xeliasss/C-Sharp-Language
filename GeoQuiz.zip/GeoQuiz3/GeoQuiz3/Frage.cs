﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeoQuiz3
{
    public class Frage
    {
        public string Land { get; set; }
        public string Hauptstadt { get; set; }
        public string FlaggenDatei { get; set; }
        
    }
}
