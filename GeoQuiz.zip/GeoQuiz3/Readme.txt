GeoQuiz

GeoQuiz ist ein interaktives geografisches Quizspiel in C# (Windows Forms), bei dem Benutzer ihr Wissen über Länder, Hauptstädte und Flaggen testen können. Das Spiel verwendet eine MySQL-Datenbank zur Speicherung von Fragen und Highscores.




Funktionen

Auswahl zwischen verschiedenen Quiz-Modi:

Land erraten anhand der Hauptstadt oder Flagge

Hauptstadt erraten anhand des Landes oder der Flagge

Flagge erraten anhand des Landes oder der Hauptstadt

Dynamische Generierung von Fragen aus einer MySQL-Datenbank

Anzeige von Bildern (Flaggen) im Quiz

Verwaltung und Anzeige von Highscores







Projektstruktur

Benutzer.cs: Eingabe des Spielernamens

Quiz_WahlForms.cs: Auswahl des Quiz-Modus (Was soll erraten/angezeigt werden?)

QuizForms.cs: Spiel-Logik, Anzeige der Fragen, Antwortüberprüfung, Punktesystem

Datenbank.cs: Datenbankverbindung und Abfragen (Fragen laden, Highscores speichern/laden)

Frage.cs: Modellklasse für Länderfragen

HighscoreEintrag.cs: Modellklasse für Highscore-Einträge








Voraussetzungen

.NET Framework oder .NET Core (für Windows Forms)

MySQL Server mit einer Datenbank geo_quiz

Tabelle laender mit den Spalten: land, hauptstadt, flagge_datei

Tabelle highscores mit den Spalten: spieler, punkte, datum

Flaggenbilder im Verzeichnis flags/png mit Dateinamen wie z.B. DE.png, FR.png usw.





Beispielhafte SQL-Struktur

CREATE TABLE laender (
    land VARCHAR(100),
    hauptstadt VARCHAR(100),
    flagge_datei VARCHAR(100)
);

CREATE TABLE highscores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    spieler VARCHAR(100),
    punkte INT,
    datum DATETIME
);



Starten des Projekts

Datenbank geo_quiz und Tabellen erstellen

Projekt in Visual Studio oder einer anderen C# IDE öffnen

Sicherstellen, dass das Verzeichnis flags/png mit Flaggenbildern existiert

Anwendung kompilieren und starten

Hinweise

Die Verbindung zur Datenbank ist aktuell lokal (localhost) auf den Benutzer root eingestellt – ggf. anpassen!

Flaggenbilder müssen genau benannt sein (z.B. DE.png für Deutschland)



Viel Spaß beim Quizzen! 🌍🧠

